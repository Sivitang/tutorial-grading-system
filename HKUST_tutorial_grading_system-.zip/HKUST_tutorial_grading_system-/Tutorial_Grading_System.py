# -*- coding: utf-8 -*-
"""
Created on Mon Mar  8 21:13:33 2021

@author: pub
"""


import numpy as np
import pandas as pd
import tkinter as tk
import tkinter.filedialog as fd
import os
import csv

#file_address='D:\\PHYS1112spring\\tutorial\\tutorial4\\T1.csv'
#T1=pd.read_csv(file_address)

#T1_useful=[T1["User Name"],T1["User Email"],T1["Question"]]
#T1_real_useful=np.transpose(T1_useful)


#Email_List=list(dict.fromkeys(T1["User Name"]))
#Question_ID=list(dict.fromkeys(T1["User Email"]))



#Answer_Sheet=[[email,[0 for j in Question_ID]] for email in Email_List]

def extract_info(address):
    T1=pd.read_csv(address)
    return(T1)
    
def Get_Answer(num,Email_List,Answer_Sheet,T1_real_useful,Question_ID):
    student=Email_List[num]
    answer =[]
    student_sheet=Answer_Sheet[num]
    for index in np.arange(len(T1_real_useful)):
        if T1_real_useful[index][0] ==student:
            answer = np.append(answer,[T1_real_useful[index][1],T1_real_useful[index][2]])
    answer=np.reshape(answer,(int(len(answer)/2),2))   
    
    
    for index0 in np.arange(len(Question_ID)):
        for index in np.arange(len(answer)):
            if Question_ID[index0] ==answer[index][0]:
                student_sheet[1][index]=answer[index][1]
    return(student_sheet)



def Grade_Answer(index):
    T1=file_content[index]
    Email_List=list(dict.fromkeys(T1["User Name"]))
    Question_ID=list(dict.fromkeys(T1["User Email"]))
    T1_useful=[T1["User Name"],T1["User Email"],T1["Question"]]
    T1_real_useful=np.transpose(T1_useful)
    Answer_Sheet=[[email,[0 for j in Question_ID]] for email in Email_List]
    Answer_List=[Get_Answer(index,Email_List,Answer_Sheet,T1_real_useful,Question_ID) for index in np.arange(len(Email_List))]
    True_Answer=answer_list[index]
    Score_List=[[email, [0 for i in np.arange(len(Question_ID))]] for email in Email_List]
    for index in np.arange(len(Answer_List)):
        for index1 in np.arange(len(Question_ID)):
            if Answer_List[index][1][index1]==True_Answer[index1]:
                Score_List[index][1][index1]=1
            elif Answer_List[index][1][index1]==0:
                Score_List[index][1][index1]=0
            else:
                Score_List[index][1][index1]=0.75
                
    Final_Score_List=[[Score_List[index][0],max(Score_List[index][1])] for index in np.arange(len(Score_List))]
    return(Final_Score_List)

            



#True_Answer=[input(question) for question in Question_ID]





Tutorial_Grading_System=tk.Tk()
Tutorial_Grading_System.title("HKUST Tutorial Grading System")
Tutorial_Grading_System.geometry('1000x700')
Tutorial_Grading_System.iconbitmap('logo.ico')
title_label=tk.Label(Tutorial_Grading_System,text='HKUST Tutorial Grading System', bg='gray25',fg='blue',font=('Times New Roman',27,'bold'))
title_label.place(relx=0.05,rely=0.04)
Tutorial_Grading_System.configure(background='gray25')

def upload_file():
    global answer_list
    global file_address
    global file_content
    file_address=fd.askopenfilenames(parent=Tutorial_Grading_System,title='Upload Tutorial Files')
    file_name=[os.path.split(file_address[index])[1] for index in np.arange(len(file_address))]
    list_var.set(file_name)
    file_content=[extract_info(address) for address in file_address]
    answer_list=[" " for index in np.arange(len(file_address))]
    answer_var.set(answer_list)

 
    
    
def input_answer():
    file_value=list_box.get(list_box.curselection())
    num=list_box.get(0,"end").index(file_value)
    answer=answer_entry.get()
    answer_box.delete(num)
    answer_box.insert(num,answer)
    answer_entry.delete(0,'end')
    answer_list[num]=list(answer)


def Tell_question(evt):
    file_value=list_box.get(list_box.curselection())
    num=list_box.get(0,"end").index(file_value)
    file_path=file_address[num]
    T1=pd.read_csv(file_path)
    Question_ID=list(dict.fromkeys(T1["User Email"]))
    question="Input the answers of following questions \n"
    for item in Question_ID:
        question=question+item+"\n \n"
    info_box.delete(1.0,'end')
    info_box.insert('end',question)



def grade_list():
    global student_order
    email_address=fd.askopenfilenames(parent=Tutorial_Grading_System,title='Upload Student List')[0]
    student_order=extract_info(email_address)['Email List']
    
def cal_export_grade():
    final_score=[]
    for index in np.arange(len(file_content)):
        final_score=final_score+Grade_Answer(index)
    order_score=[[email,0] for email in student_order]
    for email in order_score:
        for score in final_score:
            if email[0]==score[0]:
                email[1]=score[1]
    saving_path=fd.asksaveasfile(mode='w',defaultextension=".csv")
    score_data={'User Email':[order_score[index][0] for index in np.arange(len(order_score))],'Score':[order_score[index][1] for index in np.arange(len(order_score))]}
    final_score_csv=pd.DataFrame(score_data)
    final_score_csv.to_csv(saving_path,line_terminator='\n')

hkust_image=tk.PhotoImage(file='HKUST.png')
hkust_label=tk.Label(Tutorial_Grading_System,image=hkust_image,bg='gray25')
hkust_label.place(relx=0.6,rely=0.07)    



upload_image=tk.PhotoImage(file='upload.png')
upload_button=tk.Button(Tutorial_Grading_System,image=upload_image,bg='gray25',command=upload_file)
upload_button["border"]="0"
upload_button.place(relx=0.15,rely=0.13)



export_image=tk.PhotoImage(file='export_logo.png')
export_button=tk.Button(Tutorial_Grading_System,image=export_image,bg='gray25',command=cal_export_grade)
export_button["border"]='0'
export_button.place(relx=0.75,rely=0.73)


student_image=tk.PhotoImage(file='student_list_logo.png').subsample(2)
email_button=tk.Button(Tutorial_Grading_System,image=student_image,bg='gray25',command=grade_list)
email_button["border"]="0"
email_button.place(relx=0.3,rely=0.2)


import_image=tk.PhotoImage(file='input.png').subsample(3)
import_answer=tk.Button(Tutorial_Grading_System,image=import_image,bg='gray25',command=input_answer)
import_answer["border"]="0"
import_answer.place(relx=0.44,rely=0.5)

answer_entry=tk.Entry(Tutorial_Grading_System,bg='gray50',width=20,bd=5)
answer_entry.place(relx=0.44,rely=0.45)

list_var=tk.StringVar()
answer_var=tk.StringVar()
list_box=tk.Listbox(Tutorial_Grading_System,listvariable=list_var,bg='black',fg='white',width=35,height=10)
list_box.bind('<<ListboxSelect>>',Tell_question)
list_box.place(relx=0.15,rely=0.4)


answer_box=tk.Listbox(Tutorial_Grading_System,listvariable=answer_var,bg='black',fg='white',width=35,height=10)
answer_box.place(relx=0.65,rely=0.4)


info_box=tk.Text(Tutorial_Grading_System,bg='black',fg='white',width=50,height=10)
info_box.place(relx=0.35,rely=0.7)


copyright_label=tk.Label(Tutorial_Grading_System,text=u"\u00A9" + " 2021  Qianhang Ding & Sivi Tang",bg='gray25',font=('Times New Roman',10))
copyright_label.place(relx=0.8,rely=0.96)

Tutorial_Grading_System.mainloop()











